import json
import logging
import time
import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb = boto3.resource("dynamodb")
client = boto3.client("dynamodb")
table_name = "voidmap_ephemeral_signals"
table = dynamodb.Table(table_name)

CORS_HEADERS = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, OPTIONS"
}

def lambda_handler(event, context):
    http_method = event.get("httpMethod") or event.get("requestContext", {}).get("http", {}).get("method", "")
    if http_method == "OPTIONS":
        return _response(200, {"message": "OK"})

    start_time = time.time()
    try:
        # 1. Scan the table for active signals (small table due to 30-min TTL)
        items = []
        scan_params = {
            "ProjectionExpression": "geo"
        }
        
        while True:
            response = table.scan(**scan_params)
            items.extend(response.get("Items", []))
            last_key = response.get("LastEvaluatedKey")
            if not last_key:
                break
            scan_params["ExclusiveStartKey"] = last_key
            
        db_duration_ms = int((time.time() - start_time) * 1000)
        
        # 2. Compute Stats
        total_signals = len(items)
        unique_geohashes = len(set(item["geo"] for item in items if "geo" in item))
        
        # 3. Estimate cost savings from TTL
        # Storage cost is $0.25 per GB-month. Average item size is ~150 bytes.
        # Writes per month = total_signals * 1440
        projected_monthly_writes = total_signals * 1440
        projected_storage_gb = (projected_monthly_writes * 150) / (1024 ** 3)
        estimated_ttl_savings_usd = round(projected_storage_gb * 0.25, 6)
        
        # 4. Describe table to get metadata (free API call)
        desc_res = client.describe_table(TableName=table_name)
        desc_table = desc_res.get("Table", {})
        total_historical_count = desc_table.get("ItemCount", 0)
        table_size_bytes = desc_table.get("TableSizeBytes", 0)

        response_body = {
            "total_active_signals": total_signals,
            "active_geohash_zones": unique_geohashes,
            "estimated_ttl_savings_usd": estimated_ttl_savings_usd,
            "table_metadata": {
                "total_approx_historical_signals": total_historical_count,
                "table_size_bytes": table_size_bytes
            },
            "server_db_duration_ms": db_duration_ms
        }
        
        return _response(200, response_body)

    except Exception as e:
        logger.error(f"Failed to compile stats: {e}", exc_info=True)
        return _response(500, {"error": "Failed to compile stats"})

def _response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": CORS_HEADERS,
        "body": json.dumps(body)
    }
